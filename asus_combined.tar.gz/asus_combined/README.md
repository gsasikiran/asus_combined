# Dataset Description

* camera used : ASUS
* Location : NAGOYA
* Augmented : YES
* number of images per augmentation : 2
* Type of augmentation : HSV based Value randomness for emulating lighting conditions

#Standing objects
* camera : ASUS
* location : lab
* Augmented : NO

Add the missing classes also



